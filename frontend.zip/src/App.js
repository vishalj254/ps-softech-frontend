import React from 'react';
//import Paperbase from './Components/Paperbase'
// import UploadProgram from './Components/Paperbase'
import AdminRouter from './Components/AdminRouter'
import Python from './Components/UserView/Theme/modules/views/Node'
import UserLogin from './Components/UserLogin'
import DisplayAll from './Components/ExamView/maincategory/DisplayPageWise'
function App() {
  return (
    <div>
      <AdminRouter/>
      {/* <DisplayAll/> */}

    </div>
  );
}

export default App;
